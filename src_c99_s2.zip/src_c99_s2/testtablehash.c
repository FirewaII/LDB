#include "tablehash.h"
#include <stdio.h>
#include <inttypes.h>

int main(void)
{
    // a completer
    return 0;
}

